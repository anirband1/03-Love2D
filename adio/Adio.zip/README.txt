To open the game:
Right click on the game and click 'open'.
Then click 'open' again when the security warning appears

Controls:
Space or Up arrow to jump
Arrow keys to move
'B' to boost while jumping
'R' to switch tile textures